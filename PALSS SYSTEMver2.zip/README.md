
  # PALSS SYSTEM

  This is a code bundle for PALSS SYSTEM. The original project is available at https://www.figma.com/design/bqJXxoBej6wYv11POOclfE/PALSS-SYSTEM.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  