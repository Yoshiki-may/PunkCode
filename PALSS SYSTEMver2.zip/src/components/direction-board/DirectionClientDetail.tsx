import { useState } from 'react';
import { 
  ArrowLeft, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  TrendingUp,
  TrendingDown,
  Users, 
  Heart, 
  MessageCircle,
  Eye,
  Target,
  AlertCircle,
  RotateCcw,
  ChevronRight,
  FileText,
  BarChart3,
  Lightbulb,
  BookOpen,
  Share2,
  Archive,
  Upload,
  Filter,
  Search,
  X,
  Check,
  Download,
  ExternalLink,
  History,
  Flag,
  Link,
  Bell,
  ArrowUp,
  Zap,
  PlayCircle,
  Image as ImageIcon,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';

interface DirectionClientDetailProps {
  clientId?: string;
  onBack?: () => void;
}

type TabType = 'progress' | 'calendar' | 'approval' | 'report' | 'proposal' | 'brand' | 'communication' | 'archive' | 'assets';

interface Task {
  id: string;
  title: string;
  status: 'pending' | 'in-progress' | 'approval' | 'rejected' | 'completed';
  postDate: string;
  platform: 'Instagram' | 'Twitter' | 'TikTok' | 'Facebook';
  assignee: string;
  initials: string;
  rejectedCount?: number;
  dueDate?: string;
  delayReason?: string;
  nextAction?: string;
}

interface KPI {
  label: string;
  current: string;
  previous: string;
  change: number;
  icon: any;
}

interface ContentItem {
  id: string;
  title: string;
  platform: string;
  status: 'scheduled' | 'published' | 'draft';
  date: string;
  engagement?: {
    likes: number;
    comments: number;
    shares: number;
    views: number;
  };
}

interface ApprovalItem {
  id: string;
  title: string;
  type: '投稿' | '動画' | '企画書';
  submittedBy: string;
  submittedDate: string;
  platform: string;
  thumbnailUrl?: string;
}

interface Proposal {
  id: string;
  title: string;
  objective: string;
  reference: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedDate: string;
  nextMonthTicket?: boolean;
}

const mockClient = {
  id: 'client-1',
  name: '株式会社サンプル',
  industry: '美容・コスメ',
  contractStart: '2024.04.01',
  platforms: ['Instagram', 'Twitter', 'TikTok'],
  monthlyPosts: 32,
  activeProjects: 5
};

const mockTasks: Task[] = [
  {
    id: 't1',
    title: '新商品ローンチキャンペーン投稿',
    status: 'approval',
    postDate: '2025.12.24',
    dueDate: '2025.12.22',
    platform: 'Instagram',
    assignee: 'Yamada',
    initials: 'YH',
    nextAction: 'クライアント最終確認待ち'
  },
  {
    id: 't2',
    title: 'クリスマス限定セール告知',
    status: 'rejected',
    postDate: '2025.12.23',
    dueDate: '2025.12.21',
    platform: 'Twitter',
    assignee: 'Sato',
    initials: 'SM',
    rejectedCount: 2,
    delayReason: 'クリエイティブ差戻し2回',
    nextAction: '修正版再提出（本日中）'
  },
  {
    id: 't3',
    title: '年末セール事前告知',
    status: 'in-progress',
    postDate: '2025.12.26',
    dueDate: '2025.12.24',
    platform: 'Instagram',
    assignee: 'Tanaka',
    initials: 'TT',
    nextAction: 'コピーライティング完成後デザイン着手'
  },
  {
    id: 't4',
    title: 'インフルエンサーコラボ投稿',
    status: 'pending',
    postDate: '2025.12.28',
    dueDate: '2025.12.26',
    platform: 'TikTok',
    assignee: 'Suzuki',
    initials: 'SK',
    nextAction: 'インフルエンサー素材受領待ち'
  }
];

const mockKPIs: KPI[] = [
  {
    label: 'フォロワー数',
    current: '24,580',
    previous: '23,120',
    change: 6.3,
    icon: Users
  },
  {
    label: '平均いいね数',
    current: '1,845',
    previous: '1,620',
    change: 13.9,
    icon: Heart
  },
  {
    label: 'エンゲージメント率',
    current: '7.2%',
    previous: '6.8%',
    change: 5.9,
    icon: TrendingUp
  },
  {
    label: '平均リーチ数',
    current: '18,230',
    previous: '16,890',
    change: 7.9,
    icon: Eye
  }
];

const mockApprovals: ApprovalItem[] = [
  {
    id: 'a1',
    title: '新商品ローンチキャンペーン投稿',
    type: '投稿',
    submittedBy: 'Yamada',
    submittedDate: '2025.12.19 10:30',
    platform: 'Instagram'
  },
  {
    id: 'a2',
    title: '年末挨拶動画',
    type: '動画',
    submittedBy: 'Sato',
    submittedDate: '2025.12.19 09:15',
    platform: 'TikTok'
  },
  {
    id: 'a3',
    title: '1月キャンペーン企画書',
    type: '企画書',
    submittedBy: 'Tanaka',
    submittedDate: '2025.12.18 16:45',
    platform: 'Instagram'
  }
];

const mockProposals: Proposal[] = [
  {
    id: 'p1',
    title: 'バレンタインキャンペーン企画',
    objective: 'Z世代女性の認知拡大とUGC創出',
    reference: '@cosmebrand_official の #ShareYourLove キャンペーン',
    status: 'pending',
    submittedDate: '2025.12.15',
    nextMonthTicket: true
  },
  {
    id: 'p2',
    title: 'インフルエンサーコラボ企画',
    objective: '新規顧客層へのリーチ拡大',
    reference: '美容系マイクロインフルエンサー5名との連携',
    status: 'approved',
    submittedDate: '2025.12.10'
  },
  {
    id: 'p3',
    title: 'TikTokチャレンジ企画',
    objective: 'ブランド認知とバイラル狙い',
    reference: '#BeautyChallenge トレンド活用',
    status: 'rejected',
    submittedDate: '2025.12.08'
  }
];

export function DirectionClientDetail({ clientId, onBack }: DirectionClientDetailProps) {
  const [activeTab, setActiveTab] = useState<TabType>('progress');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const tabs = [
    { id: 'progress' as TabType, label: '進捗管理', icon: Target },
    { id: 'calendar' as TabType, label: '投稿カレンダー', icon: Calendar },
    { id: 'approval' as TabType, label: '承認センター', icon: CheckCircle2, badge: 3 },
    { id: 'report' as TabType, label: 'レポート', icon: BarChart3 },
    { id: 'proposal' as TabType, label: '企画提案', icon: Lightbulb },
    { id: 'brand' as TabType, label: 'ブランドガイド', icon: BookOpen },
    { id: 'communication' as TabType, label: 'コミュニケーション', icon: MessageCircle },
    { id: 'archive' as TabType, label: '納品アーカイブ', icon: Archive },
    { id: 'assets' as TabType, label: '素材共有', icon: Share2 }
  ];

  const getPlatformColor = (platform: string) => {
    const colors: Record<string, string> = {
      'Instagram': 'bg-gradient-to-br from-purple-500 to-pink-500',
      'Twitter': 'bg-blue-400',
      'TikTok': 'bg-black dark:bg-white',
      'Facebook': 'bg-blue-600'
    };
    return colors[platform] || 'bg-gray-500';
  };

  const getStatusBadge = (status: Task['status']) => {
    const configs = {
      'pending': { bg: 'bg-muted', text: 'text-muted-foreground', label: '未着手', icon: Clock },
      'in-progress': { bg: 'bg-blue-500/10', text: 'text-blue-600 dark:text-blue-400', label: '制作中', icon: Target },
      'approval': { bg: 'bg-amber-500/10', text: 'text-amber-600 dark:text-amber-400', label: '承認待ち', icon: AlertCircle },
      'rejected': { bg: 'bg-destructive/10', text: 'text-destructive', label: '差戻し', icon: RotateCcw },
      'completed': { bg: 'bg-green-500/10', text: 'text-green-600 dark:text-green-400', label: '完了', icon: CheckCircle2 }
    };
    const config = configs[status];
    const Icon = config.icon;
    return (
      <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full ${config.bg} ${config.text} text-xs`}>
        <Icon className="w-3 h-3" strokeWidth={2} />
        <span>{config.label}</span>
      </div>
    );
  };

  const renderProgressTab = () => (
    <div className="space-y-4">
      {mockTasks.map((task) => (
        <div key={task.id} className="bg-card rounded-xl border border-border p-5 hover:border-primary/50 transition-colors">
          <div className="flex items-start gap-4">
            <div className={`w-10 h-10 rounded-xl ${getPlatformColor(task.platform)} flex items-center justify-center flex-shrink-0`}>
              <div className="w-5 h-5 bg-white/90 rounded-md" />
            </div>
            
            <div className="flex-1 space-y-3">
              <div className="flex items-start justify-between gap-4">
                <h3 className="text-card-foreground">{task.title}</h3>
                {getStatusBadge(task.status)}
              </div>

              {/* Progress Details */}
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground text-xs">投稿予定日</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <Calendar className="w-4 h-4 text-primary" strokeWidth={2} />
                    <span className="text-card-foreground">{task.postDate}</span>
                  </div>
                </div>
                <div>
                  <span className="text-muted-foreground text-xs">制作期限</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400" strokeWidth={2} />
                    <span className="text-card-foreground">{task.dueDate}</span>
                  </div>
                </div>
              </div>

              {/* Next Action */}
              {task.nextAction && (
                <div className="p-3 rounded-lg bg-blue-500/5 border border-blue-500/20">
                  <div className="flex items-start gap-2">
                    <Zap className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" strokeWidth={2} />
                    <div>
                      <div className="text-xs text-blue-600 dark:text-blue-400 mb-0.5">次のアクション</div>
                      <div className="text-sm text-card-foreground">{task.nextAction}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Delay Reason */}
              {task.delayReason && (
                <div className="p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" strokeWidth={2} />
                    <div>
                      <div className="text-xs text-destructive mb-0.5">遅延理由</div>
                      <div className="text-sm text-card-foreground">{task.delayReason}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Assignee */}
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs">
                  {task.initials}
                </div>
                <span>担当: {task.assignee}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderCalendarTab = () => (
    <div className="space-y-4">
      {/* Platform Filter */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setSelectedPlatform('all')}
          className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
            selectedPlatform === 'all' ? 'bg-primary text-primary-foreground' : 'bg-accent text-muted-foreground hover:bg-accent/80'
          }`}
        >
          すべて
        </button>
        {['Instagram', 'Twitter', 'TikTok', 'Facebook'].map((platform) => (
          <button
            key={platform}
            onClick={() => setSelectedPlatform(platform)}
            className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
              selectedPlatform === platform ? 'bg-primary text-primary-foreground' : 'bg-accent text-muted-foreground hover:bg-accent/80'
            }`}
          >
            {platform}
          </button>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        {/* Calendar Header */}
        <div className="bg-accent/30 p-4 border-b border-border">
          <div className="grid grid-cols-7 gap-2">
            {['日', '月', '火', '水', '木', '金', '土'].map((day) => (
              <div key={day} className="text-center text-sm text-muted-foreground">
                {day}
              </div>
            ))}
          </div>
        </div>

        {/* Calendar Body */}
        <div className="p-2">
          <div className="grid grid-cols-7 gap-2">
            {Array.from({ length: 35 }).map((_, i) => {
              const dayNum = i - 2; // Start from Dec 1 (assuming first day is Tuesday)
              const isCurrentMonth = dayNum >= 1 && dayNum <= 31;
              const hasContent = [4, 10, 15, 19, 23, 24, 26, 28].includes(dayNum);
              
              return (
                <div
                  key={i}
                  className={`aspect-square p-2 rounded-lg border transition-colors ${
                    isCurrentMonth
                      ? hasContent
                        ? 'bg-primary/5 border-primary/30 hover:bg-primary/10 cursor-pointer'
                        : 'bg-card border-border hover:bg-accent/30'
                      : 'bg-muted/20 border-transparent'
                  }`}
                >
                  {isCurrentMonth && (
                    <>
                      <div className={`text-xs mb-1 ${hasContent ? 'text-primary' : 'text-muted-foreground'}`}>
                        {dayNum}
                      </div>
                      {hasContent && (
                        <div className="space-y-0.5">
                          <div className="w-full h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
                          <div className="w-2/3 h-1 bg-blue-400 rounded-full" />
                        </div>
                      )}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-4 h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
          <span className="text-muted-foreground">Instagram</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-1 bg-blue-400 rounded-full" />
          <span className="text-muted-foreground">Twitter</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-1 bg-black dark:bg-white rounded-full" />
          <span className="text-muted-foreground">TikTok</span>
        </div>
      </div>
    </div>
  );

  const renderApprovalTab = () => (
    <div className="space-y-4">
      {mockApprovals.map((item) => (
        <div key={item.id} className="bg-card rounded-xl border border-border p-5 hover:border-primary/50 transition-colors">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-lg bg-accent flex items-center justify-center flex-shrink-0">
              <FileText className="w-8 h-8 text-muted-foreground" strokeWidth={1.5} />
            </div>

            <div className="flex-1">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-card-foreground mb-1">{item.title}</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="px-2 py-0.5 rounded bg-accent text-xs">{item.type}</span>
                    <span>•</span>
                    <span>{item.platform}</span>
                    <span>•</span>
                    <span>{item.submittedBy}が提出</span>
                    <span>•</span>
                    <span>{item.submittedDate}</span>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors text-sm">
                  <Check className="w-4 h-4" strokeWidth={2} />
                  承認
                </button>
                <button className="flex items-center gap-2 px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors text-sm">
                  <X className="w-4 h-4" strokeWidth={2} />
                  差戻し
                </button>
                <button className="flex items-center gap-2 px-4 py-2 bg-accent text-card-foreground rounded-lg hover:bg-accent/80 transition-colors text-sm">
                  <FileText className="w-4 h-4" strokeWidth={2} />
                  修正テンプレ
                </button>
                <button className="flex items-center gap-2 px-4 py-2 bg-accent text-card-foreground rounded-lg hover:bg-accent/80 transition-colors text-sm">
                  <History className="w-4 h-4" strokeWidth={2} />
                  履歴
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderReportTab = () => (
    <div className="space-y-6">
      {/* KPI Dashboard */}
      <div className="bg-card rounded-xl border border-border p-6">
        <h3 className="text-card-foreground mb-4">KPIダッシュボード（直近30日）</h3>
        <div className="grid grid-cols-4 gap-4">
          {mockKPIs.map((kpi) => {
            const Icon = kpi.icon;
            const isPositive = kpi.change > 0;
            return (
              <div key={kpi.label} className="p-4 rounded-xl bg-accent/30">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="w-4 h-4 text-primary" strokeWidth={2} />
                  </div>
                  <span className="text-xs text-muted-foreground">{kpi.label}</span>
                </div>
                <div className="text-2xl text-card-foreground mb-1">{kpi.current}</div>
                <div className="flex items-center gap-1 text-xs">
                  {isPositive ? (
                    <TrendingUp className="w-3 h-3 text-green-600 dark:text-green-400" strokeWidth={2} />
                  ) : (
                    <TrendingDown className="w-3 h-3 text-destructive" strokeWidth={2} />
                  )}
                  <span className={isPositive ? 'text-green-600 dark:text-green-400' : 'text-destructive'}>
                    {isPositive ? '+' : ''}{kpi.change}%
                  </span>
                  <span className="text-muted-foreground ml-1">({kpi.previous})</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Weekly Summary */}
      <div className="bg-card rounded-xl border border-border p-6">
        <h3 className="text-card-foreground mb-4">週次サマリー</h3>
        <div className="space-y-4">
          <div>
            <div className="text-sm text-primary mb-2">📊 結論</div>
            <p className="text-card-foreground">エンゲージメント率が前週比+13.9%と大幅改善。特にリール投稿の反応が良好。</p>
          </div>
          <div>
            <div className="text-sm text-primary mb-2">💡 理由</div>
            <p className="text-card-foreground">トレンド音源を活用したリール3本が拡散。ハッシュタグ戦略の見直しも効果的。</p>
          </div>
          <div>
            <div className="text-sm text-primary mb-2">🎯 次の打ち手</div>
            <p className="text-card-foreground">リール投稿を週2→3回に増加。UGC誘発施策として「#〇〇チャレンジ」企画を提案。</p>
          </div>
        </div>
      </div>

      {/* Top Posts Ranking */}
      <div className="bg-card rounded-xl border border-border p-6">
        <h3 className="text-card-foreground mb-4">投稿別ランキング（エンゲージメント）</h3>
        <div className="space-y-3">
          {[
            { rank: 1, title: 'クリスマスコフレ紹介リール', engagement: '8,234', platform: 'Instagram' },
            { rank: 2, title: '冬のスキンケアルーティン', engagement: '6,892', platform: 'Instagram' },
            { rank: 3, title: '限定セール告知', engagement: '5,421', platform: 'Twitter' }
          ].map((post) => (
            <div key={post.rank} className="flex items-center gap-4 p-3 rounded-lg bg-accent/30">
              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm">
                {post.rank}
              </div>
              <div className="flex-1">
                <div className="text-sm text-card-foreground">{post.title}</div>
                <div className="text-xs text-muted-foreground">{post.platform}</div>
              </div>
              <div className="text-right">
                <div className="text-lg text-card-foreground">{post.engagement}</div>
                <div className="text-xs text-muted-foreground">いいね</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderProposalTab = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-card-foreground">企画提案一覧</h3>
        <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm hover:bg-primary/90 transition-colors">
          + 新規企画
        </button>
      </div>

      {mockProposals.map((proposal) => (
        <div key={proposal.id} className="bg-card rounded-xl border border-border p-5">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-card-foreground">{proposal.title}</h3>
                {proposal.status === 'pending' && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs">
                    審議中
                  </span>
                )}
                {proposal.status === 'approved' && (
                  <span className="px-2 py-0.5 rounded-full bg-green-500/10 text-green-600 dark:text-green-400 text-xs">
                    承認済み
                  </span>
                )}
                {proposal.status === 'rejected' && (
                  <span className="px-2 py-0.5 rounded-full bg-destructive/10 text-destructive text-xs">
                    却下
                  </span>
                )}
                {proposal.nextMonthTicket && (
                  <span className="px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs">
                    来月提案
                  </span>
                )}
              </div>
              <div className="text-sm text-muted-foreground">提出日: {proposal.submittedDate}</div>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <div className="text-xs text-muted-foreground mb-1">企画の狙い</div>
              <div className="text-sm text-card-foreground">{proposal.objective}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">参考</div>
              <div className="text-sm text-card-foreground">{proposal.reference}</div>
            </div>
          </div>

          {proposal.status === 'pending' && (
            <div className="flex items-center gap-2 mt-4 pt-4 border-t border-border">
              <button className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors text-sm">
                <ThumbsUp className="w-4 h-4" strokeWidth={2} />
                承認
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors text-sm">
                <ThumbsDown className="w-4 h-4" strokeWidth={2} />
                却下
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );

  const renderBrandTab = () => (
    <div className="space-y-6">
      {/* Tone & Manner */}
      <div className="bg-card rounded-xl border border-border p-6">
        <h3 className="text-card-foreground mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-primary" strokeWidth={2} />
          トーン&マナー
        </h3>
        <div className="space-y-3 text-sm">
          <div className="p-3 rounded-lg bg-accent/30">
            <div className="text-xs text-muted-foreground mb-1">トーン</div>
            <div className="text-card-foreground">親しみやすく、明るく前向きな表現。専門用語は避け、わかりやすい言葉選び。</div>
          </div>
          <div className="p-3 rounded-lg bg-accent/30">
            <div className="text-xs text-muted-foreground mb-1">推奨ワード</div>
            <div className="text-card-foreground">「キレイ」「美しい」「輝く」「自分らしく」「自信」</div>
          </div>
        </div>
      </div>

      {/* NG Guidelines */}
      <div className="bg-card rounded-xl border border-border p-6">
        <h3 className="text-card-foreground mb-4 flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-destructive" strokeWidth={2} />
          NG事項
        </h3>
        <div className="space-y-2 text-sm">
          <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/5 border border-destructive/20">
            <X className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" strokeWidth={2} />
            <span className="text-card-foreground">他社製品との比較表現</span>
          </div>
          <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/5 border border-destructive/20">
            <X className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" strokeWidth={2} />
            <span className="text-card-foreground">効果を断定する表現（「必ず」「絶対」など）</span>
          </div>
          <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/5 border border-destructive/20">
            <X className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" strokeWidth={2} />
            <span className="text-card-foreground">ネガティブな表現（「老化」「シミ消し」など）</span>
          </div>
        </div>
      </div>

      {/* Reference Accounts */}
      <div className="bg-card rounded-xl border border-border p-6">
        <h3 className="text-card-foreground mb-4">参考アカウント</h3>
        <div className="space-y-2">
          {['@glossier', '@fentybea uty', '@rarebeauty'].map((account, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-accent/30 hover:bg-accent/50 transition-colors cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500" />
                <span className="text-sm text-card-foreground">{account}</span>
              </div>
              <ExternalLink className="w-4 h-4 text-muted-foreground" strokeWidth={2} />
            </div>
          ))}
        </div>
      </div>

      {/* Asset Rules */}
      <div className="bg-card rounded-xl border border-border p-6">
        <h3 className="text-card-foreground mb-4">素材ルール</h3>
        <div className="space-y-3 text-sm">
          <div className="p-3 rounded-lg bg-accent/30">
            <div className="text-xs text-muted-foreground mb-1">画像サイズ</div>
            <div className="text-card-foreground">Instagram: 1080×1080px（正方形）/ 1080×1350px（縦長）</div>
          </div>
          <div className="p-3 rounded-lg bg-accent/30">
            <div className="text-xs text-muted-foreground mb-1">動画仕様</div>
            <div className="text-card-foreground">TikTok: 9:16（縦型）、15-60秒推奨、MP4形式</div>
          </div>
          <div className="p-3 rounded-lg bg-accent/30">
            <div className="text-xs text-muted-foreground mb-1">ロゴ使用</div>
            <div className="text-card-foreground">必ずブランドカラー（#FF69B4）を使用。背景色との コントラスト比4.5:1以上</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCommunicationTab = () => (
    <div className="space-y-4">
      <div className="bg-card rounded-xl border border-border p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-card-foreground">制作物ごとのスレッド</h3>
          <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm hover:bg-primary/90 transition-colors">
            + 新規スレッド
          </button>
        </div>

        <div className="space-y-3">
          {mockTasks.slice(0, 3).map((task) => (
            <div key={task.id} className="p-4 rounded-lg bg-accent/30 hover:bg-accent/50 transition-colors cursor-pointer">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="text-sm text-card-foreground mb-1">{task.title}</div>
                  <div className="text-xs text-muted-foreground">最終更新: 2時間前</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs">3件の未読</span>
                  <Bell className="w-4 h-4 text-primary" strokeWidth={2} />
                </div>
              </div>
              <div className="flex items-center gap-2 mt-3">
                <div className="flex -space-x-2">
                  {['YH', 'SM', 'TT'].map((initials, i) => (
                    <div key={i} className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-[10px] border-2 border-card">
                      {initials}
                    </div>
                  ))}
                </div>
                <span className="text-xs text-muted-foreground">3人が参加中</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Escalation */}
      <div className="bg-gradient-to-br from-amber-500/10 to-amber-500/5 rounded-xl border border-amber-500/20 p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center flex-shrink-0">
            <Flag className="w-5 h-5 text-amber-600 dark:text-amber-400" strokeWidth={2} />
          </div>
          <div className="flex-1">
            <h3 className="text-card-foreground mb-2">エスカレーション</h3>
            <p className="text-sm text-muted-foreground mb-3">
              問題が発生した場合、マネージャーや上位責任者にエスカレーションできます。
            </p>
            <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors text-sm">
              <ArrowUp className="w-4 h-4" strokeWidth={2} />
              エスカレーション申請
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderArchiveTab = () => (
    <div className="space-y-4">
      {/* Search & Filter */}
      <div className="flex items-center gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" strokeWidth={2} />
          <input
            type="text"
            placeholder="投稿タイトルで検索..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-card border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-accent text-card-foreground rounded-lg hover:bg-accent/80 transition-colors text-sm">
          <Filter className="w-4 h-4" strokeWidth={2} />
          フィルター
        </button>
      </div>

      {/* Archive List */}
      <div className="grid grid-cols-2 gap-4">
        {[1, 2, 3, 4, 5, 6].map((item) => (
          <div key={item} className="bg-card rounded-xl border border-border overflow-hidden hover:border-primary/50 transition-colors cursor-pointer">
            <div className="aspect-square bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
              <PlayCircle className="w-12 h-12 text-muted-foreground" strokeWidth={1.5} />
            </div>
            <div className="p-4">
              <h4 className="text-sm text-card-foreground mb-2">クリスマスキャンペーン投稿 #{item}</h4>
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                <span>2025.12.{20 - item}</span>
                <span>Instagram</span>
              </div>
              <div className="flex items-center gap-2">
                <button className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 bg-accent rounded-lg hover:bg-accent/80 transition-colors text-xs">
                  <Download className="w-3 h-3" strokeWidth={2} />
                  DL
                </button>
                <button className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 bg-accent rounded-lg hover:bg-accent/80 transition-colors text-xs">
                  <ExternalLink className="w-3 h-3" strokeWidth={2} />
                  表示
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAssetsTab = () => (
    <div className="space-y-4">
      {/* Upload Status */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-card-foreground mb-4">素材受領ステータス</h3>
        <div className="space-y-3">
          {[
            { name: '商品画像（12月分）', status: '受領済み', date: '2025.12.15', count: 24 },
            { name: 'ブランドロゴ更新版', status: '受領済み', date: '2025.12.10', count: 3 },
            { name: '1月キャンペーン素材', status: '待機中', date: '期限: 2025.12.25', count: 0 }
          ].map((asset, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-accent/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <ImageIcon className="w-5 h-5 text-primary" strokeWidth={2} />
                </div>
                <div>
                  <div className="text-sm text-card-foreground">{asset.name}</div>
                  <div className="text-xs text-muted-foreground">{asset.date} • {asset.count}ファイル</div>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-xs ${
                asset.status === '受領済み'
                  ? 'bg-green-500/10 text-green-600 dark:text-green-400'
                  : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
              }`}>
                {asset.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Shared Links */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-card-foreground mb-4">共有リンク集</h3>
        <div className="space-y-2">
          {[
            { title: 'Googleドライブ（素材フォルダ）', url: 'drive.google.com/...' },
            { title: 'Figmaデザインファイル', url: 'figma.com/file/...' },
            { title: 'Notionブランドガイド', url: 'notion.so/...' }
          ].map((link, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-accent/30 hover:bg-accent/50 transition-colors cursor-pointer">
              <div className="flex items-center gap-3">
                <Link className="w-4 h-4 text-primary" strokeWidth={2} />
                <div>
                  <div className="text-sm text-card-foreground">{link.title}</div>
                  <div className="text-xs text-muted-foreground">{link.url}</div>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-muted-foreground" strokeWidth={2} />
            </div>
          ))}
        </div>
      </div>

      {/* Update Notifications */}
      <div className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 rounded-xl border border-blue-500/20 p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
            <Bell className="w-5 h-5 text-blue-600 dark:text-blue-400" strokeWidth={2} />
          </div>
          <div className="flex-1">
            <h3 className="text-card-foreground mb-2">差分更新の通知</h3>
            <div className="space-y-2 text-sm">
              <div className="p-2 rounded bg-card/50">
                <div className="text-card-foreground mb-1">商品画像が3件追加されました</div>
                <div className="text-xs text-muted-foreground">2時間前</div>
              </div>
              <div className="p-2 rounded bg-card/50">
                <div className="text-card-foreground mb-1">ブランドガイドが更新されました</div>
                <div className="text-xs text-muted-foreground">1日前</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'progress':
        return renderProgressTab();
      case 'calendar':
        return renderCalendarTab();
      case 'approval':
        return renderApprovalTab();
      case 'report':
        return renderReportTab();
      case 'proposal':
        return renderProposalTab();
      case 'brand':
        return renderBrandTab();
      case 'communication':
        return renderCommunicationTab();
      case 'archive':
        return renderArchiveTab();
      case 'assets':
        return renderAssetsTab();
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={onBack}
          className="p-2 hover:bg-accent rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-muted-foreground" strokeWidth={2} />
        </button>
        <div className="flex-1">
          <h1 className="text-2xl text-card-foreground mb-1">{mockClient.name}</h1>
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <span>{mockClient.industry}</span>
            <span>•</span>
            <span>契約開始: {mockClient.contractStart}</span>
            <span>•</span>
            <div className="flex items-center gap-2">
              {mockClient.platforms.map((platform) => (
                <div 
                  key={platform}
                  className={`w-6 h-6 rounded-full ${getPlatformColor(platform)} flex items-center justify-center`}
                  title={platform}
                >
                  <div className="w-3 h-3 bg-white/90 rounded-full" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="bg-card rounded-xl border border-border p-2 shadow-[0_1px_3px_0_rgba(0,0,0,0.04)]">
        <div className="flex items-center gap-1 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:bg-accent hover:text-card-foreground'
                }`}
              >
                <Icon className="w-4 h-4" strokeWidth={2} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className={`ml-1 px-1.5 py-0.5 rounded-full text-[10px] ${
                    activeTab === tab.id
                      ? 'bg-primary-foreground/20 text-primary-foreground'
                      : 'bg-primary/10 text-primary'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div>
        {renderTabContent()}
      </div>
    </div>
  );
}
